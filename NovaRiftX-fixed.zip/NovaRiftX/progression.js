import {connectPostgres} from './postgres-store.js';
import {readFileSync,mkdirSync,writeFileSync,renameSync} from 'node:fs';
import path from 'node:path';
import {randomBytes,scrypt,timingSafeEqual} from 'node:crypto';
import {catalog,dailyShop} from './public/catalog.js';
const dir=process.env.NOVA_DATA_DIR||new URL('./data/',import.meta.url).pathname;
const file=path.join(dir,'profiles.json');
if(process.env.NOVA_REQUIRE_DB==='true'&&!process.env.DATABASE_URL)throw Error('DATABASE_URL is required for durable accounts on free hosting');
const database=process.env.DATABASE_URL?await connectPostgres(process.env.DATABASE_URL):null;
let accounts=database?.accounts||{};if(!database)try{accounts=JSON.parse(readFileSync(file,'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;}
function save(){if(database){database.save(accounts);return;}mkdirSync(dir,{recursive:true});writeFileSync(file+'.tmp',JSON.stringify(accounts),{mode:0o600});renameSync(file+'.tmp',file);}
export function profile(key){if(typeof key==='string'&&/^[a-f0-9]{64}$/.test(key)&&Object.hasOwn(accounts,key))return {key,account:accounts[key]};key=randomBytes(32).toString('hex');accounts[key]={name:'Ranger',tokens:0,points:0,owned:[],equipped:{},kills:0,waves:0};save();return {key,account:accounts[key]};}
export function publicProfile(a){const {passwordHash,salt,...safe}=a;return {...safe,owned:[...a.owned],equipped:{...a.equipped},shop:dailyShop()};}
export function reward(p,wave=false){if(!p.account)return;p.account.tokens+=wave?10:1;p.account.points+=wave?100:10;p.account[wave?'waves':'kills']++;save();}
export function rename(a,name){a.name=String(name||'Ranger').slice(0,18);save();}
export function shop(a,id,equip=false){const item=catalog.find(i=>i.id===id);if(!item)throw Error('Unknown item');if(!a.owned.includes(id)){if(equip)throw Error('Buy this item first');if(item.admin)throw Error('Unlock this companion in Shop Admin');if(!dailyShop().ids.includes(id))throw Error('This item is not in today’s shop. Check the next rotation');if(!a.infiniteTokens&&a.tokens<item.price)throw Error('Not enough Rift Tokens');if(!a.infiniteTokens)a.tokens-=item.price;a.owned.push(id);}a.equipped[item.slot]=id;save();return publicProfile(a);}
export function unequip(a,slot){if(!['suit','gun','pet','back','halo','charm'].includes(slot))throw Error('Unknown slot');delete a.equipped[slot];save();}
export function leaderboard(){return Object.values(accounts).filter(a=>a.points>0).sort((a,b)=>b.points-a.points||b.kills-a.kills||a.name.localeCompare(b.name)).slice(0,100).map((a,i)=>({rank:i+1,name:a.name,points:a.points,kills:a.kills,waves:a.waves}));}

export async function authenticate(action,username,password,key){username=String(username||'').trim().toLowerCase();if(!/^[a-z0-9_]{3,24}$/.test(username))throw Error('Username: 3–24 letters, numbers or underscores');if(typeof password!=='string'||password.length<10||password.length>128)throw Error('Use a password with 10–128 characters');let entry=Object.entries(accounts).find(([,a])=>a.username===username);if(action==='register'&&entry)throw Error('Username already taken');if(action==='login'&&!entry)throw Error('Incorrect username or password');const salt=entry?.[1].salt||randomBytes(16).toString('hex');const hash=await new Promise((resolve,reject)=>scrypt(password,salt,64,(e,value)=>e?reject(e):resolve(value)));if(action==='login'){if(!timingSafeEqual(hash,Buffer.from(entry[1].passwordHash,'hex')))throw Error('Incorrect username or password');return {key:entry[0],account:entry[1]};}if(Object.values(accounts).some(a=>a.username===username))throw Error('Username already taken');const found=typeof key==='string'&&Object.hasOwn(accounts,key)&&!accounts[key].username?{key,account:accounts[key]}:profile();Object.assign(found.account,{username,salt,passwordHash:hash.toString('hex')});save();return found;}
export function saveSettings(a,settings,name){const result={};for(const key of ['nova-preferences','nova-sensitivity','nova-graphics','nova-skin'])if(typeof settings?.[key]==='string'&&settings[key].length<2048)result[key]=settings[key];a.settings=result;rename(a,name);}

export function customizePet(a,data){if(!a.equipped.pet||!a.owned.includes(a.equipped.pet))throw Error('Equip an owned pet in your locker first');const name=String(data?.name||'Companion').trim().replace(/[<>\x00-\x1f]/g,'').slice(0,20)||'Companion';if(!/^#[a-fA-F0-9]{6}$/.test(data?.color||''))throw Error('Choose a valid pet color');if(!['none','collar','halo','crown'].includes(data.accessory))throw Error('Unknown pet accessory');const size=Number(data.size);if(!Number.isFinite(size)||size<.7||size>1.3)throw Error('Pet size must be 0.7–1.3');a.petStyle={name,color:data.color,size,accessory:data.accessory};save();return publicProfile(a);}

export function shopAdmin(a,action){if(!['tokens','dragon','recall'].includes(action))throw Error('Unknown shop admin control');if(action==='tokens')a.infiniteTokens=!a.infiniteTokens;if(action==='dragon'){if(!a.owned.includes('petAdminDragon'))a.owned.push('petAdminDragon');a.equipped.pet='petAdminDragon';a.adminDragon=true;}if(action==='recall'){a.adminDragon=false;if(a.equipped.pet==='petAdminDragon')delete a.equipped.pet;}save();return publicProfile(a);}

export async function flushAccounts(){await database?.flush();}
export async function closeAccounts(){await flushAccounts();await database?.close();}
