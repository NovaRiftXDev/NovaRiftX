// Keep startup failures visible even when a dependency fails to load.
import('./client.js').catch(error => {
  console.error('NovaRiftX startup failed', error);
  document.getElementById('error').textContent = location.protocol === 'file:'
    ? 'Start NovaRiftX with npm install, then npm start, and open http://localhost:3000. Opening index.html directly cannot run the game.'
    : 'NovaRiftX could not load. Check that the complete public folder, including vendor, was uploaded, then refresh. ' + error.message;
});
